<template>
  <div style="padding:30px;">
    <el-alert :closable="false" title="team">
      <router-view />
    </el-alert>
  </div>
</template>
